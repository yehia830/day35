package com.tiy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebChatClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebChatClientApplication.class, args);
	}
}
